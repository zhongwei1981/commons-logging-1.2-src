package commons_logging_12_GroupID.commons_logging_12_ArtifactID;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
